# Design System: Tactical Minimalism

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Silent Sentinel."**

In an era of digital noise, this system prioritizes presence over presentation. It is a high-end, editorial-inspired framework designed for high-stakes environments where clarity is the only metric that matters. We reject the "dashboard-as-a-cockpit" trope in favor of a "dashboard-as-a-gallery"—one primary action per screen, framed by expansive negative space and precise, functional typography.

By utilizing intentional asymmetry and a rigid "No-Line" philosophy, we create a signature aesthetic that feels custom-tailored rather than assembled from a kit. The layout breathes, the data speaks, and the interface recedes until the moment it is needed.

---

## 2. Colors & Chromatic Logic
This system is built on a multi-tenant architecture. While the foundation is a high-contrast monochromatic palette, the system is designed to be injected with `--brand-primary` and `--brand-accent` variables without breaking the visual harmony.

### The "No-Line" Rule
**Borders are a failure of hierarchy.**
To maintain a premium, editorial feel, designers are strictly prohibited from using 1px solid borders to section off content. Boundaries must be defined exclusively through background color shifts.
*   **Tactical Implementation:** Place a `surface-container-low` section against a `surface` background to define a zone. Use white space as the primary separator.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper. Depth is achieved through "Tonal Layering":
*   **Level 0 (Base):** `surface` (#f9f9fb)
*   **Level 1 (Sections):** `surface-container-low` (#f2f4f6)
*   **Level 2 (Cards/Interaction):** `surface-container-lowest` (#ffffff)
*   **Level 3 (Tactical Overlays):** `surface-container-highest` (#dde3e9)

### Signature Textures: Glass & Gradients
Standard flat colors feel "out-of-the-box." To elevate the experience:
*   **Glassmorphism:** For floating bottom sheets and mobile map overlays, use `surface-container-lowest` at 85% opacity with a `backdrop-blur` of 20px.
*   **Subtle Gradients:** Main CTAs should utilize a 15-degree linear gradient from `primary` (#5f5e5e) to `primary-dim` (#535252) to provide a soft, tactile depth that flat fills cannot achieve.

---

## 3. Typography: The Editorial Scale
We utilize a tri-font strategy to balance elegance with tactical utility.

*   **Display & Headlines (Manrope):** Large, airy, and modern. Used to ground the user in a specific context.
    *   *Headline-LG (2rem):* Reserved for primary screen titles.
*   **UI & Body (Inter):** High legibility at small sizes. This is the workhorse for contact triage.
    *   *Title-LG (1.375rem):* Used for critical mobile data (e.g., a person’s name or a location tag).
*   **Tactical Data (Space Grotesk):** A subtle monospace for "pings," phone numbers, and timestamps.
    *   *Label-MD (0.75rem):* Informs the user of raw data without cluttering the visual hierarchy.

**Typography as Identity:** By mixing the organic curves of Manrope with the rigid, technical nature of Space Grotesk, we communicate "Sophisticated Utility."

---

## 4. Elevation & Depth
We eschew traditional drop shadows for **Ambient Occlusion**.

*   **The Layering Principle:** Depth is inherent in the color tokens. A `surface-container-lowest` card sitting on a `surface-container-low` background creates a natural lift.
*   **Ambient Shadows:** For floating elements (like mobile FABs or floating sheets), use a diffused shadow: `box-shadow: 0 12px 40px rgba(45, 51, 56, 0.06)`. Note the low opacity (6%) and large blur—it should feel like a soft shadow on a cloudy day.
*   **The Ghost Border Fallback:** If a boundary is required for accessibility, use the `outline-variant` (#acb3b8) at 15% opacity. Never use a 100% opaque border.

---

## 5. Components

### Floating Bottom Sheets (Mobile)
The heart of the map-centric UI. Sheets should use `xl` (0.75rem) rounded corners. The handle should be a subtle `surface-variant` pill. When pulled up, the background map should slightly dim using a `surface-dim` overlay.

### Geometric Status Indicators
Replace status text with geometric primitives.
*   **Active/Positive:** `tertiary` (#006e35) Solid Circle.
*   **Alert/Priority:** `error` (#9e3f4e) Square.
*   **Idle/Passive:** `outline-variant` (#acb3b8) Outlined Triangle.
These provide an "at-a-glance" tactical readout without linguistic clutter.

### Buttons & Interaction
*   **Primary:** Using the "Signature Texture" gradient. Corners at `md` (0.375rem). Text in `on-primary`.
*   **Secondary:** No background. `ghost-border` (#acb3b8 at 20%) with `primary` text.
*   **Tertiary:** Text only, `spaceGrotesk` font for a more "system-level" feel.

### Input Fields
In place of a four-sided box, use a `surface-container-high` background with a `bottom-border` only (using `outline`). This feels like a modern ledger rather than a web form. Labels should always be in `label-sm` (Space Grotesk) for a technical touch.

### Contact Lists
Strictly **No Dividers**. Use `24px` (6 units) of vertical white space to separate contact entries. Use `surface-container-low` as a hover state to define the hit area.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use asymmetrical layouts. A 2/3 and 1/3 split is more "editorial" than a 50/50 split.
*   **Do** prioritize monospace (Space Grotesk) for any string of numbers. It increases scannability.
*   **Do** lean into `surface-container-lowest` for your most important interactive cards.

### Don't
*   **Don't** use icons with fills for secondary actions; use thin-stroke (1.5px) outlines to maintain "Quiet Minimalism."
*   **Don't** use traditional "Material" blue or "Bootstrap" primary colors. Stick to the `primary` (#5f5e5e) neutrals and the `tertiary` (#006e35) greens for success states.
*   **Don't** add social features or "Gamification" elements. If it doesn't help with presence tracking or triage, it must be removed.